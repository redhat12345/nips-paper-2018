 #!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: dhouib
"""

import numpy as np
from sklearn.datasets import make_blobs
from matplotlib import pyplot as plt
import SllcModule as sllcmod
from sklearn.preprocessing import MinMaxScaler
from sklearn import model_selection
from sklearn.pipeline import Pipeline
from scipy.optimize import minimize

from scipy.stats import multivariate_normal
from scipy import special
from scipy.integrate import dblquad
from time import sleep
import os

#%%
nPts = 200
usedCV = model_selection.RepeatedStratifiedKFold()



""" Defines the integrand in the divergence between probability distributions term"""
def mixGaussianAbsDifference(x, distribSource1, distribSource2, distribTarget1, distribTarget2, isSupportIncluded):
    if isSupportIncluded:
        # log density of source
        logpdf11 = distribSource1.logpdf(x)
        logpdf12 = distribSource2.logpdf(x)
        logpdf1  = special.logsumexp([logpdf11-np.log(2), logpdf12]) - np.log(2)
            
        # log density of target
        logpdf21 = distribTarget1.logpdf(x)
        logpdf22 = distribTarget2.logpdf(x)
        logpdf2  = special.logsumexp([logpdf21, logpdf22]) - np.log(2)
        #            
        return np.exp(logpdf1)*np.maximum(special.expm1(logpdf2-logpdf1),0)**2
    else:
        pdf1= 0.5*(distribSource1.pdf(x) + distribSource2.pdf(x))
        pdf2= 0.5*(distribTarget1.pdf(x) + distribTarget2.pdf(x))
        
        return np.maximum(pdf2-pdf1,0)

""" Defines the "y.g_R(x)" term"""
def dotProdsVec(X, y, landmarks, landmarks_labels, gamma, A):
    signed_landMarksMean = np.mean(landmarks_labels[:, np.newaxis]*landmarks, axis= 0)
    return np.linalg.multi_dot((y[:,None]*X, A, signed_landMarksMean))

""" Hinge loss at every element of teh previous vector """        
def lossVec(X, y, landmarks, landmarks_labels, gamma, A):
    return np.maximum(0, 1 - dotProdsVec(X,y,landmarks,landmarks_labels, gamma, A))


def objFun(w, divergence, supportIncluded, X, y, A, gamma):
    weights= w[:-1]
    simMat = sllcmod.computeBilinSimMat(X, weights[:,None]*X, A)
    weightedMeanLoss= sllcmod.meanLoss(simMat, y, y, gamma) 
    if supportIncluded:
        return weightedMeanLoss + divergence*w[-1]*np.sqrt(weightedMeanLoss)
    else:
        return weightedMeanLoss + divergence*w[-1]
        
    
def constraintFun(w, supportIncluded, X, y, A, gamma):
    weights= w[:-1]
    if supportIncluded:
        return w[-1] - np.sqrt(lossVec(X, y, weights[:,None]*X, y, gamma, A))
    else:
        return w[-1] - lossVec(X, y, weights[:,None]*X, y, gamma, A)
    
#%% Loop over hypotheis of domination between source and target, values of standard deviation of each cluster 
sigmaRange = [0.5]
centers= np.array([[1,1],[-1,-1]])
for sigma in sigmaRange:
    
# =============================================================================
#  Generating source data   
# =============================================================================
    X, y = make_blobs(n_samples= nPts, centers= centers, cluster_std= sigma)
    y = 2*y-1
    
#    plt.scatter(*(X.T), c=y)
    
    dataRange = (-1/np.sqrt(X.shape[1]), 1/np.sqrt(X.shape[1]))
    minMaxScaler = MinMaxScaler(feature_range= dataRange)
    
    dataTransformingPipeline = Pipeline([
                                        ("min max scaling", minMaxScaler),
                                        ])
    
    
# =============================================================================
#     Cross validation of the similarity measure
# =============================================================================
    gammaRange = [0.1]#10.0 ** np.arange(-4,1)
    betaRange = 10.0 ** np.arange(-4,4)
    simLearnPipeline =  Pipeline(dataTransformingPipeline.steps
                                 +
                                 [
                                         ("SllcSim", sllcmod.SllcSimilarityLearner()),
                                ])
    
    gridSearcherSim = model_selection.GridSearchCV(estimator= simLearnPipeline,
                                param_grid= {"SllcSim__gamma": gammaRange,
                                             "SllcSim__beta_reg": betaRange,
                                             },
                                cv= usedCV,
                                n_jobs= -1, verbose= 2, return_train_score= True, error_score= 'raise')
    
    
    gridSearcherSim.fit(X, y)
    bestSimEstimator = gridSearcherSim.best_estimator_
   
    # Ensure the similarity is good for the whole source domain
    bestSimEstimator.fit(X,y)

    sleep(1)
    
    # Two components of the source domain that is a mixture f two gaussians
    distribSource1= multivariate_normal(mean= centers[0], cov= sigma**2)
    distribSource2= multivariate_normal(mean= centers[1], cov= sigma**2)
    
    # Getting the solution of the supervised case
    gamma = gridSearcherSim.best_params_['SllcSim__gamma']
    A = bestSimEstimator.steps[-1][1].paramMat_
    vecA = A.flatten(order= 'F')
    X_transformed = dataTransformingPipeline.fit_transform(X)
# =============================================================================
#     # Adapting
# ============================================================================
    for isSupportIncluded in [False, True]:
        print('\n does the source dominate the target?: {}'.format(isSupportIncluded))
        DAFolderName = 'included_support' if isSupportIncluded else 'different_supports'
        
        
        nTargetDraws= 30 # number of random target domain draws
        thetaVec = np.linspace(0, np.pi/2, 10) # rotation angles by which the target domain is obtained
        divergenceVec= np.zeros_like(thetaVec)  #  to store the divergence values
        weightsMat= np.zeros((nPts, len(thetaVec), nTargetDraws)) # weights of landmarks after optimization
        epsTargetVec0 = np.zeros((len(thetaVec), nTargetDraws))
        epsTargetVec1 = np.zeros((len(thetaVec), nTargetDraws))
                
        for k, rotTheta in enumerate(thetaVec):
            print(k)
            rotMat = np.array([[np.cos(rotTheta), -np.sin(rotTheta)], [np.sin(rotTheta), np.cos(rotTheta)]])
            targetCenters= np.dot(centers, rotMat.T)
            
            # Computing a bound on chi2 deviation restricted to margin violating points
            distribTarget1= multivariate_normal(mean= targetCenters[0], cov= sigma**2)
            distribTarget2= multivariate_normal(mean= targetCenters[1], cov= sigma**2)
       
            
        # =============================================================================
        #   Computing the divergence between the two distributions generating source and target: compute with the real generating distributions, thus independent of the draw of the target
        # =============================================================================
            integrand = lambda y,x: mixGaussianAbsDifference([x,y], distribSource1, distribSource2, distribTarget1, distribTarget2, isSupportIncluded)
            integral, integralError = dblquad(integrand, -10*sigma, 10*sigma, lambda x: -10*sigma, lambda x: 10*sigma)
            if isSupportIncluded:
                divergenceVec[k]= np.sqrt(integral)
            else:
                divergenceVec[k]= integral
            print('divergence between distributions: %f, error on integral: %f'%(integral, integralError))
            
            # =============================================================================
            # Generating target data and testing without adaptation     
            # =============================================================================
            
            for i in range(nTargetDraws):
                X_target, y_target =  make_blobs(n_samples= nPts, centers= targetCenters, cluster_std= sigma)
                y_target = 2*y_target - 1
                X_target_transformed= dataTransformingPipeline.fit_transform(X_target)
        
                    
                # Performance of the similarity funtion before optimizing over the weights
                epsTargetVec0[k, i] = 1-bestSimEstimator.score(X_target_transformed,y_target)
            
            # =============================================================================
            #       Adapting the estimator
            # =============================================================================
            
        
            # minimize the DA bound by weighting landmarks
                res = minimize(fun= objFun, x0= np.append(0.5*np.ones(nPts),10),
                               args= (divergenceVec[k], isSupportIncluded, X_transformed, y, A, gamma),
                               constraints= [{'type': 'ineq', 'fun': constraintFun, 'args': (isSupportIncluded, X_transformed, y, A, gamma)}])
                
                # Performance of the reweighting
                weightsMat[:, k, i] = res['x'][:-1]
                
                simMatTargetSource = sllcmod.computeBilinSimMat(X_target_transformed, weightsMat[:,k, i][:,None]*X_transformed, A)
                epsTargetVec1[k, i]= sllcmod.meanLoss(simMatTargetSource, y_target, y, gamma)
    
    # =============================================================================
    # Saving results
    # =============================================================================
        pathName= 'DA/'+ DAFolderName +'/sigma=%.1f' %sigma
        
        if not os.path.exists(pathName):
            os.makedirs(pathName)
            
        print(pathName)
        np.save(pathName + '/weights', weightsMat)
        np.save(pathName + '/divergence', divergenceVec)
        np.save(pathName + '/errorWithoutDA', epsTargetVec0)
        np.save(pathName + '/errorWithDA', epsTargetVec1)
    
#%% Loading results and plotting results
    
""" Plotting a curve +- standard deviation"""
def plotWithStd(xArray, yArray, axis):
    meanYArray= np.mean(yArray, axis=  axis)
    stdYArray= np.std(yArray, axis= axis)
    plt.plot(xArray, meanYArray)
    plt.fill_between(xArray, meanYArray - stdYArray, meanYArray + stdYArray, alpha= 0.3)
    return None


for sigma in sigmaRange:
    plotInd= 0
    for isSupportIncluded in [False, True]:
        supportStr = 'support included' if isSupportIncluded else 'different supports'
        
        plotInd += 1
        DAFolderName = 'included_support' if isSupportIncluded else 'different_supports'
        pathName= 'DA/'+ DAFolderName +'/sigma=%.1f' %sigma
        weightsMat    = np.load(pathName + '/weights.npy')
        divergenceVec = np.load(pathName + '/divergence.npy')
        epsTargetVec0 = np.load(pathName + '/errorWithoutDA.npy')
        epsTargetVec1 = np.load(pathName + '/errorWithDA.npy')
        
        
        
        thetaVecDeg = np.rad2deg(thetaVec)
        fig1 = plt.figure(1, figsize= (7,9))
        ax1= plt.subplot(2,1,plotInd)
        plt.semilogy(thetaVecDeg, divergenceVec)
        plt.xlabel(r'rotation angle $\theta$ (°)')
        plt.ylabel('divergence')
        plt.minorticks_on()
        plt.grid(b= True, which= 'minor')
#        ax1.title = "Support included hypothesis: {}".format(isSupportIncluded)
        
        fig2 = plt.figure(2, figsize= (7,9))
        ax2= plt.subplot(2,1, plotInd)
        plotWithStd(thetaVecDeg, epsTargetVec0*100, axis= 1)
        plotWithStd(thetaVecDeg, epsTargetVec1*100, axis= 1)
        plt.xlabel(r'rotation angle $\theta$ (°)')
        plt.ylabel('empirical goodness on target (%)')
        plt.minorticks_on()
        plt.grid(b= True, which= 'minor')
        plt.legend(['without DA', 'with DA'])
#        ax2.title = "$\epsilon$ of the similarity function"
        pathName= 'DA/'+ DAFolderName +'/sigma=%.1f' %sigma
        fig1.savefig('DA/divergence_sigma=%.1f.png' %sigma)
        fig2.savefig('DA/goodness_sigma=%.1f.png' %sigma)

    plt.close('all')