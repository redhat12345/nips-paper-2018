#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan  3 09:34:18 2018

@author: dhouib
"""
from sklearn.base import BaseEstimator, TransformerMixin
#import cvxpy as cvx
import numpy as np
from sklearn.svm import LinearSVC


class SllcSimilarityLearner(BaseEstimator, TransformerMixin):  
    """An example of classifier"""

    def __init__(self, gamma= 1, beta_reg= 1e-3, penalty= 'l2', prior= 'zero', criterion= 'hinge', solver= 'cvxpy', scoring= 'hinge'):
        self.paramMat_ = np.array([], dtype= np.float64)
        self.landmarks_ = np.array([], dtype= np.float64)
        self.landmarks_labels_ = np.array([], dtype= np.float64)
        self.set_params(**{'gamma': gamma, 'beta_reg': beta_reg, 
                           'penalty': penalty, 'prior': prior, 'solver': solver})
        self.epsilon_ = -np.inf
        self.prior= prior
        self.criterion = criterion

    def fit(self, X, y):
        params = self.get_params()
        self.paramMat_ = self.__learnSimMatrix(X, y, params['beta_reg'], params['gamma'], params['solver'])
        self.landmarks_ = X.copy()
        self.landmarks_labels_ = y.copy()
        return self
    
    def transform(self, X, landmarks= None):
        if landmarks == None:
            landmarks = self.landmarks_.copy()
        return computeBilinSimMat(X, landmarks, self.paramMat_)
        
    def score(self, X, y, landmarks= None):
        if landmarks == None:
            landmarks = self.landmarks_
        simMat = computeBilinSimMat(X, landmarks, self.paramMat_) # K(x__i, x_j) matrix
        return 1 - meanLoss(simMat, y, self.landmarks_labels_, self.get_params()['gamma'])


    def __learnSimMatrix(self, X, y, beta_reg, gamma, solver):
        
        n, d = X.shape
            
        mu = np.dot(X.T, y)/n
        X_kron = np.kron(mu, X)
        linSvc = LinearSVC(loss= 'hinge', C= 1/beta_reg, fit_intercept= False)
        linSvc.fit(X_kron/gamma, y)
        return linSvc.coef_.reshape((d,d), order= 'F')
        
def hingeLoss(x):
    return np.maximum(0, 1-x)
    
def meanLoss(simMat, w1,w2, gamma):
    return np.mean(hingeLoss(np.dot(w1[:,None]*simMat, w2)/(gamma*simMat.shape[1])))

def computeBilinSimMat(X1, X2, A):
    return np.linalg.multi_dot((X1, A, X2.T))